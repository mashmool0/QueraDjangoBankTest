from django import forms
from django.forms import ModelForm
from .models import Product
from django.core.exceptions import ValidationError


class ProductForm(ModelForm):
    class Meta:
        model = Product
        fields = "__all__"

    def clean_price(self):
        if self.price > 1000:
            raise ValidationError("Product is too expensive")
        return self.price

    def clean_description(self):
        if self.description and len(self.description) <= 20:
            raise ValidationError("Product must have a good description")
        return self.description
