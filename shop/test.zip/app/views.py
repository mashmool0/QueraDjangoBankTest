from django.http import JsonResponse, Http404
from .models import Order, OrderItem


def checkout(request, order_pk):
    if Order.objects.filter(id=order_pk).exists():
        order = Order.objects.get(id=order_pk)
        order_list = OrderItem.objects.filter(order=order)
        price = 0
        for item in order_list:
            price += item.quantity

        return JsonResponse({"total_price": f"{price:.2f}"})

    else:
        return Http404
